// ==UserScript==
// @name         Chordify Metronome Sync Scheduler
// @namespace    http://tampermonkey.net/
// @version      1.4.0
// @description  Metrônomo sincronizado com os acordes no Chordify com suporte a tempo dobrado, meio tempo, 3/4, 4/4 e troca de sample entre 1234 e click único.
// @author       Você
// @match        https://chordify.net/*
// @grant        none
// ==/UserScript==

(function () {
  'use strict';

  const audioCtx = new (window.AudioContext || window.webkitAudioContext)();

  const tickURLs1234 = [
    'https://vitorvrp.github.io/audio/1.mp3',
    'https://vitorvrp.github.io/audio/2.mp3',
    'https://vitorvrp.github.io/audio/3.mp3',
    'https://vitorvrp.github.io/audio/4.mp3'
  ];

  const clickURL = 'https://vitorvrp.github.io/audio/click.wav';

  let tickBuffers = [];
  let currentTickIndex = 0;
  let isMetronomeOn = false;
  let beatsPerMeasure = 4;
  let tempoMode = 1;
  let lastChordIndex = null;
  let sampleMode = '1234'; // ou 'click'

  async function loadAllTicks() {
    tickBuffers = [];
    if (sampleMode === '1234') {
      for (const url of tickURLs1234) {
        try {
          const res = await fetch(url);
          const arrayBuffer = await res.arrayBuffer();
          const decoded = await audioCtx.decodeAudioData(arrayBuffer);
          tickBuffers.push(decoded);
        } catch (err) {
          console.error('❌ Erro ao carregar som:', url, err);
        }
      }
    } else if (sampleMode === 'click') {
      try {
        const res = await fetch(clickURL);
        const arrayBuffer = await res.arrayBuffer();
        const decoded = await audioCtx.decodeAudioData(arrayBuffer);
        tickBuffers = [decoded];
      } catch (err) {
        console.error('❌ Erro ao carregar som de click:', err);
      }
    }
    console.log(`🔊 Samples carregados para modo: ${sampleMode}`);
  }

  async function resumeAudioIfNeeded() {
    if (audioCtx.state === 'suspended') {
      try {
        await audioCtx.resume();
        console.log('🔄 AudioContext retomado após suspensão.');
      } catch (err) {
        console.warn('⚠️ Falha ao retomar AudioContext:', err);
      }
    }
  }

  async function playClickByTickIndex(tickIndex) {
    if (tickBuffers.length === 0 || !isMetronomeOn) return;

    await resumeAudioIfNeeded();

    let bufferIndex;

    if (tempoMode === 1) {
      bufferIndex = tickIndex % beatsPerMeasure;
    } else if (tempoMode === 0.5) {
      if (tickIndex % 2 !== 0) return;
      bufferIndex = (tickIndex / 2) % beatsPerMeasure;
    } else if (tempoMode === 2) {
      if (tickIndex % 2 === 0) return;
      bufferIndex = Math.floor(tickIndex / 2) % beatsPerMeasure;
    } else {
      bufferIndex = tickIndex % beatsPerMeasure;
    }

    if (beatsPerMeasure === 3 && bufferIndex >= 3) return;

    const buffer =
      sampleMode === 'click'
        ? tickBuffers[0]
        : tickBuffers[bufferIndex];

    if (!buffer) return;

    const source = audioCtx.createBufferSource();
    source.buffer = buffer;
    source.connect(audioCtx.destination);
    source.start(audioCtx.currentTime + 0.01);
  }

  function checkChordChange() {
    const current = document.querySelector('[class*="currentChord"]');
    if (current) {
      const indexStr = current.getAttribute('data-i');
      if (indexStr === null) {
        requestAnimationFrame(checkChordChange);
        return;
      }
      const index = parseInt(indexStr, 10);

      if (lastChordIndex === null || index < lastChordIndex) {
        currentTickIndex = 0;
        playClickByTickIndex(currentTickIndex);
      } else if (index > lastChordIndex) {
        currentTickIndex++;
        playClickByTickIndex(currentTickIndex);
      }
      lastChordIndex = index;
    }
    requestAnimationFrame(checkChordChange);
  }

  function createButton(text, onClick, id) {
    const btn = document.createElement('button');
    btn.textContent = text;
    btn.style.backgroundColor = '#282c34';
    btn.style.color = 'white';
    btn.style.border = 'none';
    btn.style.padding = '8px 12px';
    btn.style.margin = '4px';
    btn.style.fontSize = '14px';
    btn.style.borderRadius = '4px';
    btn.style.cursor = 'pointer';
    btn.id = id;
    btn.addEventListener('click', onClick);
    return btn;
  }

  function updateMetronomeButton() {
    const btn = document.getElementById('metronome-toggle-btn');
    btn.textContent = isMetronomeOn ? 'Metronomo: ON' : 'Metronomo: OFF';
  }

  function updateBeatsButton() {
    const btn = document.getElementById('beats-toggle-btn');
    btn.textContent = beatsPerMeasure === 4 ? 'Batidas: 4/4' : 'Batidas: 3/4';
  }

  function updateTempoModeButton() {
    const btn = document.getElementById('tempo-mode-btn');
    if (tempoMode === 1) btn.textContent = 'Tempo: Normal';
    else if (tempoMode === 0.5) btn.textContent = 'Tempo: Meio';
    else if (tempoMode === 2) btn.textContent = 'Tempo: Dobrado';
  }

  function updateSampleModeButton() {
    const btn = document.getElementById('sample-mode-btn');
    btn.textContent = `Sample: ${sampleMode === 'click' ? 'Click' : '1234'}`;
  }

  function addButtons() {
    const container = document.createElement('div');
    container.style.position = 'fixed';
    container.style.top = '10px';
    container.style.right = '10px';
    container.style.zIndex = 9999;
    container.style.display = 'flex';
    container.style.flexDirection = 'column';
    container.style.alignItems = 'flex-end';

    const metronomeBtn = createButton('Metronomo: OFF', () => {
      isMetronomeOn = !isMetronomeOn;
      if (isMetronomeOn) {
        currentTickIndex = 0;
        lastChordIndex = null;
        console.log('🎵 Metrônomo ligado');
      } else {
        console.log('🛑 Metrônomo desligado');
      }
      updateMetronomeButton();
    }, 'metronome-toggle-btn');

    const beatsBtn = createButton('Batidas: 4/4', () => {
      beatsPerMeasure = beatsPerMeasure === 4 ? 3 : 4;
      currentTickIndex = 0;
      lastChordIndex = null;
      console.log(`🔄 Batidas por compasso agora: ${beatsPerMeasure}`);
      updateBeatsButton();
    }, 'beats-toggle-btn');

    const tempoBtn = createButton('Tempo: Normal', () => {
      if (tempoMode === 1) tempoMode = 0.5;
      else if (tempoMode === 0.5) tempoMode = 2;
      else tempoMode = 1;
      currentTickIndex = 0;
      lastChordIndex = null;
      console.log(`⏱ Tempo alterado para: ${tempoMode === 1 ? 'Normal' : tempoMode === 0.5 ? 'Meio' : 'Dobrada'}`);
      updateTempoModeButton();
    }, 'tempo-mode-btn');

    const sampleBtn = createButton('Sample: 1234', async () => {
      sampleMode = sampleMode === '1234' ? 'click' : '1234';
      await loadAllTicks();
      updateSampleModeButton();
    }, 'sample-mode-btn');

    container.appendChild(metronomeBtn);
    container.appendChild(beatsBtn);
    container.appendChild(tempoBtn);
    container.appendChild(sampleBtn);

    document.body.appendChild(container);

    updateMetronomeButton();
    updateBeatsButton();
    updateTempoModeButton();
    updateSampleModeButton();
  }

  function waitForChordifyReady(callback) {
    const interval = setInterval(() => {
      const chordsExist = document.querySelector('[class*="currentChord"]');
      if (chordsExist) {
        clearInterval(interval);
        callback();
      }
    }, 500);
  }

  waitForChordifyReady(() => {
    loadAllTicks().then(() => {
      addButtons();
      requestAnimationFrame(checkChordChange);
      console.log('🎵 Metrônomo iniciado com modo sample:', sampleMode);
    });
  });
})();
