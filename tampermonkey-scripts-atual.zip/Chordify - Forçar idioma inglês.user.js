// ==UserScript==
// @name         Chordify - Forçar idioma inglês
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Redireciona automaticamente qualquer URL do chordify.net para a versão em inglês (/en/)
// @author       Você
// @match        https://chordify.net/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Checa se já está na versão inglesa
    if (!location.pathname.startsWith('/en/')) {
        // Monta a nova URL com o caminho atual
        const newUrl = 'https://chordify.net/en' + location.pathname + location.search + location.hash;
        window.location.replace(newUrl);
    }
})();
