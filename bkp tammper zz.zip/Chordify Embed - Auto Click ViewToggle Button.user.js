// ==UserScript==
// @name         Chordify Embed - Auto Click ViewToggle Button
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Clica automaticamente no botão #viewToggle em páginas de embed do Chordify
// @match        https://chordify.net/en/embed/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    function blockAutoScroll() {
        window.scrollTo = () => console.log('[×] scrollTo bloqueado');
        window.scrollBy = () => console.log('[×] scrollBy bloqueado');

        const blockScrollTop = (el) => {
            let value = 0;
            Object.defineProperty(el, 'scrollTop', {
                get: () => value,
                set: (v) => {
                    console.log('[×] scrollTop bloqueado');
                    value = v;
                },
                configurable: true
            });
        };

        blockScrollTop(document.documentElement);
        blockScrollTop(document.body);
        console.log('[✓] Scroll automático bloqueado (scroll manual permitido).');
    }
    function clickButton() {
        const button = document.querySelector('#viewToggle button');
        if (button) {
            console.log('Botão #viewToggle encontrado. Clicando...');
            button.click();
            return true;
        }
        return false;
    }

    // Tenta clicar imediatamente
    if (!clickButton()) {
        // Se não encontrou, observa mudanças no DOM para tentar clicar quando aparecer
        const observer = new MutationObserver((mutations, obs) => {
            if (clickButton()) {
                obs.disconnect();
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }
     blockAutoScroll();
})();
