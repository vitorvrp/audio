// ==UserScript==
// @name         Mini Gráfico de Cotações Colorido (Canvas Puro)
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  Mini gráficos leves e coloridos para cotações ao vivo
// @match        https://www.panoramalaatus.com.br/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    const intervaloSegundos = 5;
    const duracaoMinutos = 30;
    const maxPontos = (duracaoMinutos * 60) / intervaloSegundos;
    const largura = 100;
    const altura = 30;

    const ativos = document.querySelectorAll('td.last-quote');
    const series = {};

    ativos.forEach(el => {
        const pidMatch = el.className.match(/pid-(\d+)-last/);
        if (!pidMatch) return;

        const pid = pidMatch[1];
        series[pid] = [];

        // Cria canvas
        const canvas = document.createElement('canvas');
        canvas.width = largura;
        canvas.height = altura;
        canvas.style.marginTop = '4px';
        canvas.style.display = 'block';

        el.parentElement.appendChild(canvas);
        const ctx = canvas.getContext('2d');

        // Desenha o gráfico
        function desenhar(data) {
            ctx.clearRect(0, 0, largura, altura);
            if (data.length < 2) return;

            const valores = data.map(d => d.valor);
            const min = Math.min(...valores);
            const max = Math.max(...valores);
            const escalaY = max - min || 1;

            // Define a cor com base na variação
            const primeira = valores[0];
            const ultima = valores[valores.length - 1];
            let cor = '#aaa'; // neutro
            if (ultima > primeira) cor = '#00ff88'; // verde
            else if (ultima < primeira) cor = '#ff5555'; // vermelho

            ctx.beginPath();
            ctx.strokeStyle = cor;
            ctx.lineWidth = 1;

            data.forEach((ponto, i) => {
                const x = (i / (maxPontos - 1)) * largura;
                const y = altura - ((ponto.valor - min) / escalaY) * altura;
                i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
            });

            ctx.stroke();
        }

        // Atualizador
        setInterval(() => {
            const texto = el.textContent.replace('.', '').replace(',', '.');
            const valor = parseFloat(texto);
            if (isNaN(valor)) return;

            const agora = Date.now();
            const dados = series[pid];

            dados.push({ tempo: agora, valor });

            // remove pontos com mais de 30min
            const limite = agora - duracaoMinutos * 60 * 1000;
            while (dados.length > 0 && dados[0].tempo < limite) {
                dados.shift();
            }

            desenhar(dados);
        }, intervaloSegundos * 1000);
    });
})();
