// ==UserScript==
// @name         Chordify Bypass
// @namespace    http://tampermonkey.net/
// @version      2025-06-21
// @description  try to take over the world!
// @match        https://chordify.net/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=chordify.net
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    document.body.style.backgroundColor = '#d2c8c2';
    const groupColors = ['darkblue', 'darkgreen', 'darkred', 'darkorange', 'darkviolet', 'darkcyan'];
    let groups = [];
    let currentGroup = new Set();
    let currentColorIndex = 0;

    let isDragging = false;
    let dragStart = { x: 0, y: 0 };
    let selectionBox = null;

    const container = document.getElementById('chords');
    if (!container) {
        console.warn('[×] Container #chords não encontrado. O script pode não funcionar corretamente.');
        return;
    }

    container.setAttribute('tabindex', '0');

    // === Menu de cores ===
    const colorPicker = document.createElement('div');
    colorPicker.style.position = 'fixed';
    colorPicker.style.top = '50%';
    colorPicker.style.left = '50%';
    colorPicker.style.transform = 'translate(-50%, -50%)';
    colorPicker.style.padding = '10px';
    colorPicker.style.backgroundColor = '#fff';
    colorPicker.style.border = '2px solid #0099ff';
    colorPicker.style.borderRadius = '8px';
    colorPicker.style.zIndex = '10000';
    colorPicker.style.display = 'none';

    // NOVO CSS para deixar bem vertical, cores em coluna, sem texto, botões de ação em coluna
    colorPicker.style.boxShadow = '0 0 10px rgba(0,0,0,0.3)';
    colorPicker.style.width = '70px';
    colorPicker.style.display = 'flex';
    colorPicker.style.flexDirection = 'column';
    colorPicker.style.alignItems = 'center';
    colorPicker.style.gap = '10px';
    colorPicker.style.userSelect = 'none';
    document.body.appendChild(colorPicker);

    function hideColorPicker() {
        colorPicker.style.display = 'none';
    }

    function showColorPicker() {
        colorPicker.innerHTML = '';

        // botões de cor - só o botão colorido, sem texto
        groupColors.forEach((color, index) => {
            const btn = document.createElement('button');
            btn.style.backgroundColor = color;
            btn.style.border = 'none';
            btn.style.margin = '0';
            btn.style.padding = '12px';
            btn.style.width = '40px';
            btn.style.height = '30px';
            btn.style.cursor = 'pointer';
            btn.style.borderRadius = '4px';
            btn.title = `Aplicar cor ${color}`;
            btn.addEventListener('click', () => {
                applyColorToCurrentGroup(index);
                hideColorPicker();
                container.focus();
            });
            colorPicker.appendChild(btn);
        });

        // Botões de ação com labels curtos e tooltip, em coluna
        const actions = [
            {
                label: 'Fake Chord',
                title: 'Substituir por Fake Chord (Ctrl+Y)',
                action: () => {
                    if (currentGroup.size === 0) {
                        console.warn('[×] Nenhum elemento selecionado para substituir.');
                        return;
                    }
                    currentGroup.forEach(el => {
                        const fakeChord = document.createElement('div');
                        fakeChord.className = 'fake-chord';
                        el.parentNode.replaceChild(fakeChord, el);
                    });
                    currentGroup.clear();
                    hideColorPicker();
                    container.focus();
                }
            },
            {
                label: 'Limpar Seleção',
                title: 'Limpar seleção (sem remover cor)',
                action: () => {
                    currentGroup.forEach(el => el.style.boxShadow = '');
                    currentGroup.clear();
                    hideColorPicker();
                    container.focus();
                }
            },
            {
                label: 'Limpar Cor',
                title: 'Remover cor + seleção',
                action: () => {
                    currentGroup.forEach(el => {
                        el.style.outline = '';
                        el.style.boxShadow = '';
                    });
                    currentGroup.clear();
                    hideColorPicker();
                    container.focus();
                }
            },
            {
                label: 'Duplicar',
                title: 'Duplicar acordes (Ctrl+X)',
                action: () => {
                    if (currentGroup.size === 0) {
                        console.warn('[×] Nenhum elemento selecionado para duplicar.');
                        return;
                    }
                    currentGroup.forEach(el => {
                        const clone = el.cloneNode(true);
                        clone.style.outline = '';
                        clone.style.boxShadow = '';
                        el.parentNode.insertBefore(clone, el.nextSibling);
                    });
                    hideColorPicker();
                    container.focus();
                }
            }
        ];

        actions.forEach(({label, title, action}) => {
            const btn = document.createElement('button');
            btn.textContent = label;
            btn.title = title;
            btn.style.backgroundColor = '#444';
            btn.style.color = 'white';
            btn.style.border = 'none';
            btn.style.margin = '0';
            btn.style.padding = '8px 6px';
            btn.style.width = '100%';
            btn.style.cursor = 'pointer';
            btn.style.borderRadius = '4px';
            btn.style.fontSize = '13px';
            btn.addEventListener('click', action);
            colorPicker.appendChild(btn);
        });

        colorPicker.style.display = 'flex';
    }

    document.addEventListener('click', e => {
        if (colorPicker.style.display === 'flex' && !colorPicker.contains(e.target)) {
            hideColorPicker();
        }
    });

    // Funções para seleção com box-shadow para seleção e outline para cor
    function highlightSelection(el) {
        el.style.boxShadow = '0 0 10px 3px red';
    }
    function unhighlightSelection(el) {
        el.style.boxShadow = '';
    }
    function highlightElementColor(el, color) {
        el.style.outline = `4px solid ${color}`;
    }
    function unhighlightElementColor(el) {
        el.style.outline = '';
    }

    function isSelectableChord(el) {
        return el.classList && el.classList.contains('chord');
    }

    function toggleSelection(el, withCtrl = false) {
        if (!container.contains(el)) return;
        if (!isSelectableChord(el)) return;

        if (withCtrl) {
            if (currentGroup.has(el)) {
                currentGroup.delete(el);
                unhighlightSelection(el);
            } else {
                currentGroup.add(el);
                highlightSelection(el);
            }
        } else {
            currentGroup.forEach(unhighlightSelection);
            currentGroup.clear();
            currentGroup.add(el);
            highlightSelection(el);
        }
    }

    function applyColorToCurrentGroup(colorIndex) {
        if (currentGroup.size === 0) {
            console.warn('[×] Nenhum elemento selecionado para colorir.');
            return;
        }

        const color = groupColors[colorIndex ?? currentColorIndex];
        currentGroup.forEach(el => {
            unhighlightSelection(el);
            highlightElementColor(el, color);
        });

        groups.push({ elements: new Set(currentGroup), color });
        currentGroup.clear();

        currentColorIndex = (colorIndex + 1) % groupColors.length;

        console.log(`[✓] Grupo colorido com "${color}" aplicado e seleção limpa.`);
    }

    // Função para criar/atualizar/remover caixa de seleção (arraste)
    function createSelectionBox() {
        selectionBox = document.createElement('div');
        selectionBox.style.position = 'fixed';
        selectionBox.style.border = '2px dashed #0099ff';
        selectionBox.style.backgroundColor = 'rgba(0, 153, 255, 0.2)';
        selectionBox.style.pointerEvents = 'none';
        selectionBox.style.zIndex = '9999';
        document.body.appendChild(selectionBox);
    }
    function updateSelectionBox(x1, y1, x2, y2) {
        const left = Math.min(x1, x2);
        const top = Math.min(y1, y2);
        const width = Math.abs(x2 - x1);
        const height = Math.abs(y2 - y1);
        selectionBox.style.left = left + 'px';
        selectionBox.style.top = top + 'px';
        selectionBox.style.width = width + 'px';
        selectionBox.style.height = height + 'px';
    }
    function removeSelectionBox() {
        if (selectionBox) {
            document.body.removeChild(selectionBox);
            selectionBox = null;
        }
    }

    function isElementInRect(el, rect) {
        const elRect = el.getBoundingClientRect();
        return !(
            elRect.right < rect.left ||
            elRect.left > rect.right ||
            elRect.bottom < rect.top ||
            elRect.top > rect.bottom
        );
    }

    document.addEventListener('mousedown', e => {
        if (e.ctrlKey && e.button === 0 && container.contains(e.target) && isSelectableChord(e.target)) {
            e.preventDefault();
            isDragging = true;
            dragStart.x = e.clientX;
            dragStart.y = e.clientY;
            createSelectionBox();
        }
    });

    document.addEventListener('mousemove', e => {
        if (!isDragging || !selectionBox) return;
        e.preventDefault();
        updateSelectionBox(dragStart.x, dragStart.y, e.clientX, e.clientY);
        const rect = {
            left: Math.min(dragStart.x, e.clientX),
            top: Math.min(dragStart.y, e.clientY),
            right: Math.max(dragStart.x, e.clientX),
            bottom: Math.max(dragStart.y, e.clientY)
        };
        currentGroup.forEach(unhighlightSelection);
        currentGroup.clear();
        const allElements = container.querySelectorAll('.chord');
        allElements.forEach(el => {
            if (isElementInRect(el, rect)) {
                currentGroup.add(el);
                highlightSelection(el);
            }
        });
    });

    document.addEventListener('mouseup', e => {
        if (isDragging) {
            e.preventDefault();
            isDragging = false;
            removeSelectionBox();
            console.log(`[✓] Seleção múltipla finalizada. ${currentGroup.size} elemento(s) selecionado(s).`);
            container.focus();
        }
    });

    document.addEventListener('click', e => {
        if (e.ctrlKey && container.contains(e.target) && isSelectableChord(e.target)) {
            e.preventDefault();
            toggleSelection(e.target, true);
            container.focus();
        }
    });

    container.addEventListener('contextmenu', e => {
        if (currentGroup.size > 0 && container.contains(e.target)) {
            e.preventDefault();
            showColorPicker();
        }
    });

    // Atalhos de teclado para ações rápidas
    document.addEventListener('keydown', e => {
        if (e.ctrlKey && e.key.toLowerCase() === 'x') {
            e.preventDefault();
            if (currentGroup.size === 0) {
                console.warn('[×] Nenhum elemento selecionado para duplicar.');
                return;
            }
            currentGroup.forEach(el => {
                const clone = el.cloneNode(true);
                clone.style.outline = '';
                clone.style.boxShadow = '';
                el.parentNode.insertBefore(clone, el.nextSibling);
                console.log('[✓] Elemento duplicado!', clone);
            });
        }
        if (e.ctrlKey && e.key.toLowerCase() === 'y') {
            e.preventDefault();
            if (currentGroup.size === 0) {
                console.warn('[×] Nenhum elemento selecionado para substituir.');
                return;
            }
            currentGroup.forEach(el => {
                const fakeChord = document.createElement('div');
                fakeChord.className = 'fake-chord';
                el.parentNode.replaceChild(fakeChord, el);
                console.log('[✓] Elemento substituído por <div class="fake-chord"></div>');
            });
            currentGroup.clear();
            hideColorPicker();
            container.focus();
        }
    });

    function blockAutoScroll() {
        window.scrollTo = () => console.log('[×] scrollTo bloqueado');
        window.scrollBy = () => console.log('[×] scrollBy bloqueado');

        const blockScrollTop = el => {
            let value = 0;
            Object.defineProperty(el, 'scrollTop', {
                get: () => value,
                set: v => {
                    console.log('[×] scrollTop bloqueado');
                    value = v;
                },
                configurable: true
            });
        };
        blockScrollTop(document.documentElement);
        blockScrollTop(document.body);

        Element.prototype.scrollIntoView = function() {
            console.log('[×] scrollIntoView bloqueado');
        };

        const originalFocus = HTMLElement.prototype.focus;
        HTMLElement.prototype.focus = function(options) {
            if (options && typeof options === 'object' && options.preventScroll) {
                originalFocus.call(this, options);
            } else {
                console.log('[×] focus() com scroll bloqueado');
                originalFocus.call(this, { preventScroll: true });
            }
        };

        console.log('[✓] Scroll automático bloqueado de forma avançada (scrollTo, scrollBy, scrollIntoView, focus)');
    }

    blockAutoScroll();

    function clickButton() {
        const button = document.querySelector("#viewToggle button");

        if (button) {
            console.log('Botão #viewToggle encontrado. Clicando...');
            button.click();
            return true;
        }
        return false;
    }

    if (!clickButton()) {
        const observer = new MutationObserver((mutations, obs) => {
            if (clickButton()) {
                obs.disconnect();
            }
        });
        observer.observe(document.body, { childList: true, subtree: true });
    }

    console.log(`Modo ativado:
- Ctrl + arrastar com mouse esquerdo: seleção múltipla com box-shadow vermelho
- Ctrl + clique esquerdo: selecionar/deselecionar individualmente (box-shadow vermelho)
- Botão direito com seleção: menu para aplicar cor (outline), limpar seleção (remove box-shadow), remover cor (remove outline e box-shadow), duplicar
- Ctrl + X: duplicar seleção
- Ctrl + Y: substituir por fake chord
- Scroll automático bloqueado, scroll manual permitido
`);
})();
