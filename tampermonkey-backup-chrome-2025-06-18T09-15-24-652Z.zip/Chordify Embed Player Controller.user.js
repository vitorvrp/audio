// ==UserScript==
// @name         Chordify Embed Player Controller
// @namespace    http://tampermonkey.net/
// @version      1.5
// @description  Clica automaticamente no primeiro acorde até que o Chordify comece a reproduzir e responde pedido de requestStorageAccess
// @match        https://chordify.net/embed/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    function isPlaying() {
        return Chordify.player.mediaInteractor.state === 'playing';
    }

    function clickUntilPlaying(){
        if (isPlaying()) {
            console.log('Chordify já está tocando.');
            return;
        }

        const chord = document.querySelector('.chord[data-i="0"]');
        if (chord) {
            chord.click();
            console.log('Primeiro acorde clicado!');
        } else {
            console.warn('Primeiro acorde NÃO encontrado.');
        }

        setTimeout(clickUntilPlaying, 1000);
    }

    clickUntilPlaying();

    window.addEventListener('message', (event) => {
        if (event.origin !== 'https://music.youtube.com') return;

        const data = event.data;
        if (!data || !data.command) return;

        try {
            switch (data.command) {
                case 'play':
                    Chordify.player.play();
                    break;
                case 'pause':
                    Chordify.player.pause();
                    break;
                case 'seek':
                    if (typeof data.amount === 'number') {
                        Chordify.player.seek(data.amount);
                    }
                    break;
                case 'requestStorageAccess':
                    if (document.requestStorageAccess) {
                        document.requestStorageAccess().then(() => {
                            console.log('Storage access granted.');
                        }).catch(() => {
                            console.log('Storage access denied.');
                        });
                    }
                    break;
                default:
                    console.warn('Comando desconhecido!', data);
            }
        } catch (e) {
            console.error('Erro no controle do player Chordify!', e);
        }
    });
})();
