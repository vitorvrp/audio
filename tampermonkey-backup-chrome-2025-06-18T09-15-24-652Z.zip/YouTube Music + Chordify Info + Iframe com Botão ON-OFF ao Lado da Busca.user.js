// ==UserScript==
// @name         YouTube Music + Chordify Info + Iframe com Botão ON/OFF ao Lado da Busca
// @namespace    http://tampermonkey.net/
// @version      1.6.1
// @description  Adiciona Key, BPM ao título do YouTube Music e iframe do Chordify fixo com botão ON/OFF ao lado da busca. Botão minimiza/maximiza o iframe dinamicamente e pausa o YouTube ao abrir.
// @author       Você
// @match        https://music.youtube.com/*
// @grant        GM_xmlhttpRequest
// @connect      chordify.net
// ==/UserScript==

(function () {
    'use strict';

    const NOTES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
    const enharmonics = {
        'Cb': 'B', 'Db': 'C#', 'Eb': 'D#', 'Fb': 'E',
        'Gb': 'F#', 'Ab': 'G#', 'Bb': 'A#',
        'E#': 'F', 'B#': 'C'
    };
    const reverseEnharmonics = {
        'C#': 'Db', 'D#': 'Eb', 'F#': 'Gb', 'G#': 'Ab', 'A#': 'Bb'
    };

    let lastVideoId = null;
    let mutationObserver = null;

    function getRelativeKey(key) {
        const [rawNote, type] = key.split(':');
        const sharpNote = enharmonics[rawNote] || rawNote;
        const idx = NOTES.indexOf(sharpNote);
        if (idx === -1 || !type) return key;

        let relativeNote;
        if (type === 'min') {
            relativeNote = NOTES[(idx + 3) % 12];
        } else if (type === 'maj') {
            relativeNote = NOTES[(idx + 9) % 12];
        } else {
            return key;
        }

        if (rawNote.includes('b') && reverseEnharmonics[relativeNote]) {
            relativeNote = reverseEnharmonics[relativeNote];
        }

        return `${key}/${relativeNote}:${type === 'min' ? 'maj' : 'min'}`;
    }

    function formatBpmVariants(bpm) {
        const half = (bpm / 2).toFixed(1);
        const double = (bpm * 2).toFixed(0);
        return `${bpm}/${half}/${double}`;
    }

    function fetchChordifyInfo(videoId, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: `https://chordify.net/api/v2/songs/youtube:${videoId}`,
            headers: { "Accept": "application/json" },
            onload: function (response) {
                try {
                    const data = JSON.parse(response.responseText);
                    callback(null, data);
                } catch (err) {
                    callback(err, null);
                }
            },
            onerror: function (err) {
                callback(err, null);
            }
        });
    }

    function clearPreviousInfo(titleEl) {
        if (!titleEl) return;
        const spans = titleEl.querySelectorAll('span[data-chordify]');
        spans.forEach(span => span.remove());
        titleEl.dataset.chordifyUpdated = 'false';

        const oldOpenBtn = document.getElementById('chordify-open-btn');
        if (oldOpenBtn) oldOpenBtn.remove();
    }

    function isPlayButtonAvailable() {
        const btn = document.querySelector("button.style-scope.yt-icon-button[aria-label='Pausar']");
        return btn && btn.offsetParent !== null ? btn : null;
    }

    function tryPauseYouTube(retries = 40) {
        const playBtn = isPlayButtonAvailable();
        if (playBtn) {
            console.log('[Chordify] Pausando YouTube Music...');
            playBtn.click();
        } else if (retries > 0) {
            setTimeout(() => tryPauseYouTube(retries - 1), 100);
        } else {
            console.log('[Chordify] Botão Pausar não encontrado.');
        }
    }

    function toggleIframeMinimize() {
        const iframe = document.getElementById('chordify-iframe-simple');
        const toggleBtn = document.getElementById('chordify-toggle-btn');
        if (!iframe) return;

        const isMinimized = iframe.dataset.minimized === 'true';

        if (isMinimized) {
            iframe.style.width = '650px';
            iframe.style.height = '1060px';
            iframe.dataset.minimized = 'false';
            localStorage.setItem('chordifyIframeMinimized', 'false');
            if (toggleBtn) toggleBtn.textContent = 'OFF';
            tryPauseYouTube();
        } else {
            iframe.style.width = '650px';
            iframe.style.height = '30px';
            iframe.dataset.minimized = 'true';
            localStorage.setItem('chordifyIframeMinimized', 'true');
            if (toggleBtn) toggleBtn.textContent = 'ON';
        }
    }

    function updateTitleWithInfo(titleEl, infoText) {
        if (!titleEl) return;

        clearPreviousInfo(titleEl);

        const wrapperSpan = document.createElement('span');
        wrapperSpan.dataset.chordify = 'true';
        wrapperSpan.style.marginLeft = '10px';

        const infoSpan = document.createElement('span');
        infoSpan.textContent = infoText;
        infoSpan.style.color = '#1db954';

        wrapperSpan.appendChild(infoSpan);
        titleEl.appendChild(wrapperSpan);
        titleEl.dataset.chordifyUpdated = 'true';

        // Criar botão ON/OFF se não existir
        if (!document.getElementById('chordify-toggle-btn')) {
            const clearBtn = document.querySelector('#clear-button');
            if (clearBtn && clearBtn.parentNode) {
                const toggleBtn = document.createElement('button');
                toggleBtn.id = 'chordify-toggle-btn';
                toggleBtn.textContent = localStorage.getItem('chordifyIframeMinimized') === 'true' ? 'ON' : 'OFF';
                toggleBtn.style.marginLeft = '10px';
                toggleBtn.style.padding = '4px 8px';
                toggleBtn.style.fontSize = '12px';
                toggleBtn.style.cursor = 'pointer';
                toggleBtn.style.background = '#1db954';
                toggleBtn.style.color = 'white';
                toggleBtn.style.border = 'none';
                toggleBtn.style.borderRadius = '4px';

                toggleBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    toggleIframeMinimize();
                });

                clearBtn.parentNode.insertBefore(toggleBtn, clearBtn.nextSibling);
            }
        }
    }

    function createOrUpdateIframe(slug) {
        let iframe = document.getElementById('chordify-iframe-simple');
        if (!iframe) {
            iframe = document.createElement('iframe');
            iframe.id = 'chordify-iframe-simple';
            iframe.style.position = 'fixed';
            iframe.style.top = '50px';
            iframe.style.left = '800px';
            iframe.style.border = '2px solid #1db954';
            iframe.style.zIndex = 999999;
            document.body.appendChild(iframe);
        }

        iframe.src = `https://chordify.net/en/embed/${slug}`;

        const savedMinimized = localStorage.getItem('chordifyIframeMinimized');
        if (savedMinimized === 'true') {
            iframe.style.width = '650px';
            iframe.style.height = '30px';
            iframe.dataset.minimized = 'true';
        } else {
            iframe.style.width = '650px';
            iframe.style.height = '1060px';
            iframe.dataset.minimized = 'false';
            tryPauseYouTube();
        }
    }

    function createOpenButton(videoId) {
        const existingOpenBtn = document.getElementById('chordify-open-btn');
        if (existingOpenBtn) return;

        const clearBtn = document.querySelector('#clear-button');
        if (clearBtn && clearBtn.parentNode) {
            const openBtn = document.createElement('button');
            openBtn.id = 'chordify-open-btn';
            openBtn.textContent = 'Open';
            openBtn.style.marginLeft = '10px';
            openBtn.style.padding = '4px 8px';
            openBtn.style.fontSize = '12px';
            openBtn.style.cursor = 'pointer';
            openBtn.style.background = '#555';
            openBtn.style.color = 'white';
            openBtn.style.border = 'none';
            openBtn.style.borderRadius = '4px';

            openBtn.addEventListener('click', () => {
                window.open(`https://chordify.net/search/https%3A%2F%2Fyoutu.be%2F${videoId}`, '_blank');
            });

            const toggleBtn = document.getElementById('chordify-toggle-btn');
            if (toggleBtn) {
                toggleBtn.parentNode.insertBefore(openBtn, toggleBtn.nextSibling);
            } else {
                clearBtn.parentNode.insertBefore(openBtn, clearBtn.nextSibling);
            }
        }
    }

    function processMusic() {
        const videoId = new URLSearchParams(window.location.search).get('v');
        const titleEl = document.querySelector('yt-formatted-string.title.style-scope.ytmusic-player-bar');

        if (!videoId || !titleEl) return;

        // Só roda se videoId mudou MESMO
        if (videoId === lastVideoId) return;

        lastVideoId = videoId;
        clearPreviousInfo(titleEl);

        fetchChordifyInfo(videoId, (err, data) => {
            if (err || !data) return;

            if (data.errorCode === 'SongNotFound') {
                updateTitleWithInfo(titleEl, 'NotKeyAndBPM');
                createOpenButton(videoId);
                const iframe = document.getElementById('chordify-iframe-simple');
                if (iframe) iframe.src = '';
                return;
            }

            const bpm = data.chordInfo?.derivedBpm;
            const key = data.chordInfo?.derivedKey;
            const slug = data.slug;

            if (bpm && key && slug) {
                const fullKey = getRelativeKey(key);
                const fullBpm = formatBpmVariants(bpm);
                const keyFormatted = fullKey.replace(':', '').replace(':', '');
                const infoText = `Key: ${keyFormatted} | BPM: ${fullBpm}`;
                updateTitleWithInfo(titleEl, infoText);
                createOrUpdateIframe(slug);
            }
        });
    }

    function observeChanges() {
        const playerBar = document.querySelector('ytmusic-player-bar');
        if (!playerBar) return;

        // Se já tiver observer ativo, desconecta para evitar duplicidade
        if (mutationObserver) {
            mutationObserver.disconnect();
        }

        mutationObserver = new MutationObserver(() => {
            setTimeout(processMusic, 300);
        });

        mutationObserver.observe(playerBar, {
            childList: true,
            subtree: true
        });
    }

    // Limitar tentativas para evitar rodar forever
    let tries = 0;
    const maxTries = 30;
    const waitForPlayerBar = setInterval(() => {
        const player = document.querySelector('ytmusic-player-bar');
        if (player) {
            clearInterval(waitForPlayerBar);
            observeChanges();
            processMusic();
        } else if (tries >= maxTries) {
            clearInterval(waitForPlayerBar);
            console.warn('[Chordify] playerBar não encontrado após tentativas máximas.');
        }
        tries++;
    }, 500);
})();
