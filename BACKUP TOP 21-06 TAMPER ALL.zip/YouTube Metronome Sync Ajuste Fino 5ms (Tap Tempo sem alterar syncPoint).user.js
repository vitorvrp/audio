// ==UserScript==
// @name         YouTube Metronome Sync Ajuste Fino 5ms (Tap Tempo sem alterar syncPoint)
// @namespace    http://tampermonkey.net/
// @version      1.14
// @description  Metrônomo sincronizado com ajuste fino de 5 ms, botões Start, Stop, Tap Tempo, e atalho Ctrl+Enter, sem alterar syncPoint no tap
// @author       Você
// @match        https://www.youtube.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const sounds = [
        'https://vitorvrp.github.io/audio/1.mp3',
        'https://vitorvrp.github.io/audio/2.mp3',
        'https://vitorvrp.github.io/audio/3.mp3',
        'https://vitorvrp.github.io/audio/4.mp3'
    ];

    const fineAdjustStep = 0.005;

    function waitForVideo() {
        const video = document.querySelector('video');
        if (!video) {
            setTimeout(waitForVideo, 1000);
            return;
        }
        initMetronome(video);
    }

    function initMetronome(video) {
        let bpm = 60;
        let audio = new Audio();
        let playing = false;
        let metronomeActive = false;
        let scheduledTimeout = null;
        let lastBeatNumber = null;
        let syncPointTime = 0;

        const tapTimes = [];
        const maxTaps = 5;

        const videoControls = document.createElement('div');
        videoControls.style.position = 'absolute';
        videoControls.style.top = '10px';
        videoControls.style.left = '10px';
        videoControls.style.backgroundColor = 'rgba(0, 0, 0, 0.8)';
        videoControls.style.color = 'white';
        videoControls.style.padding = '10px';
        videoControls.style.borderRadius = '8px';
        videoControls.style.zIndex = 9999;
        videoControls.style.fontFamily = 'Arial, sans-serif';
        videoControls.style.userSelect = 'none';
        videoControls.style.width = '220px';
        videoControls.style.display = 'flex';
        videoControls.style.flexDirection = 'column';
        videoControls.style.alignItems = 'stretch';
        videoControls.style.boxSizing = 'border-box';

        const bpmContainer = document.createElement('div');
        bpmContainer.style.display = 'flex';
        bpmContainer.style.alignItems = 'center';
        bpmContainer.style.marginBottom = '10px';

        const bpmLabel = document.createElement('label');
        bpmLabel.textContent = 'BPM:';
        bpmLabel.style.marginRight = '8px';
        bpmLabel.style.minWidth = '35px';

        const bpmInput = document.createElement('input');
        bpmInput.type = 'number';
        bpmInput.min = '20';
        bpmInput.max = '300';
        bpmInput.value = bpm;
        bpmInput.style.flexGrow = '1';
        bpmInput.style.height = '28px';
        bpmInput.style.padding = '2px 5px';
        bpmInput.style.fontSize = '14px';

        bpmInput.addEventListener('keydown', (e) => {
            e.stopPropagation();
        });

        bpmContainer.appendChild(bpmLabel);
        bpmContainer.appendChild(bpmInput);

        const startStopContainer = document.createElement('div');
        startStopContainer.style.display = 'flex';
        startStopContainer.style.gap = '8px';
        startStopContainer.style.marginBottom = '10px';

        const startBtn = document.createElement('button');
        startBtn.textContent = 'Start';
        startBtn.style.flex = '1';
        startBtn.style.height = '32px';
        startBtn.style.fontSize = '14px';

        const stopBtn = document.createElement('button');
        stopBtn.textContent = 'Stop';
        stopBtn.disabled = true;
        stopBtn.style.flex = '1';
        stopBtn.style.height = '32px';
        stopBtn.style.fontSize = '14px';

        startStopContainer.appendChild(startBtn);
        startStopContainer.appendChild(stopBtn);

        const adjustContainer = document.createElement('div');
        adjustContainer.style.display = 'flex';
        adjustContainer.style.gap = '8px';
        adjustContainer.style.marginBottom = '10px';

        const adjustBackBtn = document.createElement('button');
        adjustBackBtn.textContent = '← Ajuste -';
        adjustBackBtn.title = 'Atrasa o início do metrônomo';
        adjustBackBtn.disabled = true;
        adjustBackBtn.style.flex = '1';
        adjustBackBtn.style.height = '28px';
        adjustBackBtn.style.fontSize = '12px';

        const adjustForwardBtn = document.createElement('button');
        adjustForwardBtn.textContent = 'Ajuste + →';
        adjustForwardBtn.title = 'Adianta o início do metrônomo';
        adjustForwardBtn.disabled = true;
        adjustForwardBtn.style.flex = '1';
        adjustForwardBtn.style.height = '28px';
        adjustForwardBtn.style.fontSize = '12px';

        adjustContainer.appendChild(adjustBackBtn);
        adjustContainer.appendChild(adjustForwardBtn);

        const bpmAdjustContainer = document.createElement('div');
        bpmAdjustContainer.style.display = 'flex';
        bpmAdjustContainer.style.gap = '8px';
        bpmAdjustContainer.style.marginBottom = '10px';

        const bpmDownBtn = document.createElement('button');
        bpmDownBtn.textContent = '− BPM';
        bpmDownBtn.style.flex = '1';
        bpmDownBtn.style.height = '28px';
        bpmDownBtn.style.fontSize = '12px';

        const bpmUpBtn = document.createElement('button');
        bpmUpBtn.textContent = '+ BPM';
        bpmUpBtn.style.flex = '1';
        bpmUpBtn.style.height = '28px';
        bpmUpBtn.style.fontSize = '12px';

        bpmAdjustContainer.appendChild(bpmDownBtn);
        bpmAdjustContainer.appendChild(bpmUpBtn);

        const tapTempoBtn = document.createElement('button');
        tapTempoBtn.textContent = 'Tap Tempo';
        tapTempoBtn.title = 'Clique repetidamente para medir BPM';
        tapTempoBtn.style.height = '32px';
        tapTempoBtn.style.fontSize = '14px';
        tapTempoBtn.style.marginBottom = '10px';

        const syncInfo = document.createElement('div');
        syncInfo.style.marginTop = '8px';
        syncInfo.style.fontSize = '12px';
        syncInfo.style.color = '#ccc';

        videoControls.appendChild(bpmContainer);
        videoControls.appendChild(startStopContainer);
        videoControls.appendChild(adjustContainer);
        videoControls.appendChild(bpmAdjustContainer);
        videoControls.appendChild(tapTempoBtn);
        videoControls.appendChild(syncInfo);

        const player = document.querySelector('.html5-video-player');
        if (player) {
            player.style.position = 'relative';
            player.appendChild(videoControls);
        } else {
            document.body.appendChild(videoControls);
        }

        function playBeat(beatNumber) {
            const soundIndex = ((beatNumber - 1) % sounds.length + sounds.length) % sounds.length;
            audio.src = sounds[soundIndex];
            audio.play();
        }

        function scheduleNextBeat() {
            if (!playing) return;

            const currentTime = video.currentTime;
            const beatInterval = 60 / bpm;
            const elapsed = currentTime - syncPointTime;
            const beatNumber = Math.round(elapsed / beatInterval);

            if (beatNumber !== lastBeatNumber) {
                playBeat(beatNumber + 1);
                lastBeatNumber = beatNumber;
            }

            const nextBeatTime = syncPointTime + (beatNumber + 1) * beatInterval;
            const timeToNextBeat = (nextBeatTime - currentTime) * 1000;

            scheduledTimeout = setTimeout(scheduleNextBeat, Math.max(timeToNextBeat, 0));
        }

        function updateSyncInfo() {
            syncInfo.textContent = `Sync Point (tempo 1): ${syncPointTime.toFixed(3)}s | BPM: ${bpm}`;
        }

        function startMetronome() {
            bpm = parseFloat(bpmInput.value);
            if (isNaN(bpm) || bpm < 20 || bpm > 300) {
                alert('Insira um BPM válido entre 20 e 300');
                return;
            }

            syncPointTime = video.currentTime;

            startBtn.disabled = true;
            stopBtn.disabled = false;
            bpmInput.disabled = true;
            adjustBackBtn.disabled = false;
            adjustForwardBtn.disabled = false;

            metronomeActive = true;
            playing = !video.paused;
            lastBeatNumber = null;

            updateSyncInfo();

            if (playing) scheduleNextBeat();
        }

        function stopMetronome() {
            metronomeActive = false;
            playing = false;
            if (scheduledTimeout) {
                clearTimeout(scheduledTimeout);
                scheduledTimeout = null;
            }
            lastBeatNumber = null;
            syncPointTime = 0;

            startBtn.disabled = false;
            stopBtn.disabled = true;
            bpmInput.disabled = false;
            adjustBackBtn.disabled = true;
            adjustForwardBtn.disabled = true;

            updateSyncInfo();
        }

        function adjustSyncPoint(delta) {
            syncPointTime += delta;
            if (syncPointTime < 0) syncPointTime = 0;
            lastBeatNumber = null;
            updateSyncInfo();
        }

        function adjustBpm(delta) {
            let newBpm = bpm + delta;
            if (newBpm >= 20 && newBpm <= 300) {
                bpm = newBpm;
                bpmInput.value = newBpm;
                updateSyncInfo();
            }
        }

        function registerTap() {
            const now = performance.now();

            tapTimes.push(now);
            if (tapTimes.length > maxTaps) {
                tapTimes.shift();
            }

            if (tapTimes.length >= 2) {
                let intervals = [];
                for (let i = 1; i < tapTimes.length; i++) {
                    intervals.push(tapTimes[i] - tapTimes[i - 1]);
                }
                const avgInterval = intervals.reduce((a, b) => a + b, 0) / intervals.length;
                const newBpm = Math.round(60000 / avgInterval);

                if (newBpm >= 20 && newBpm <= 300) {
                    bpmInput.value = newBpm;
                    bpm = newBpm;
                    updateSyncInfo();
                }
            }
        }

        startBtn.addEventListener('click', startMetronome);
        stopBtn.addEventListener('click', stopMetronome);
        adjustBackBtn.addEventListener('click', () => adjustSyncPoint(-fineAdjustStep));
        adjustForwardBtn.addEventListener('click', () => adjustSyncPoint(fineAdjustStep));
        bpmDownBtn.addEventListener('click', () => adjustBpm(-1));
        bpmUpBtn.addEventListener('click', () => adjustBpm(1));
        tapTempoBtn.addEventListener('click', registerTap);

        window.addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.key === 'Enter') {
                e.preventDefault();
                registerTap();
            }
        });

        video.addEventListener('pause', () => {
            playing = false;
            if (scheduledTimeout) {
                clearTimeout(scheduledTimeout);
                scheduledTimeout = null;
            }
        });

        video.addEventListener('play', () => {
            if (metronomeActive && !playing) {
                playing = true;
                scheduleNextBeat();
            }
        });

        updateSyncInfo();
    }

    waitForVideo();
})();
