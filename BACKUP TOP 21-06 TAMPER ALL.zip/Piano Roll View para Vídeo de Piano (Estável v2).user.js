// ==UserScript==
// @name         Piano Roll View para Vídeo de Piano (Estável v2)
// @namespace    http://tampermonkey.net/
// @version      1.3
// @description  Rotaciona vídeo em 90 graus e espelha para simular piano roll (sem sumir ao voltar)
// @match        https://www.youtube.com/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    let rotated = false;
    let originalStyle = null;

    function createButton() {
        const btn = document.createElement('button');
        btn.id = 'piano-roll-btn';
        btn.textContent = '🎹 Modo Piano Roll';
        Object.assign(btn.style, {
            position: 'fixed',
            bottom: '20px',
            left: '20px',
            zIndex: 9999,
            padding: '10px 15px',
            background: '#1a1a1a',
            color: '#00ff99',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer',
            fontSize: '14px',
            fontWeight: 'bold'
        });

        btn.onclick = () => {
            const video = document.querySelector('video');
            if (!video) return;

            if (!rotated) {
                // Salva estilos originais
                originalStyle = video.getAttribute('style');

video.style.transform = 'rotate(90deg) scaleX(-1) scale(0.85)';
video.style.transformOrigin = 'center center';
video.style.position = 'fixed';
video.style.top = '50%';
video.style.left = '50%';
video.style.width = '100vh';
video.style.height = '100vw';
video.style.objectFit = 'contain';
video.style.zIndex = '9998';
video.style.pointerEvents = 'none';
video.style.margin = '0';
video.style.translate = '-50% -50%';


                rotated = true;
                btn.textContent = '🔄 Voltar ao Normal';
            } else {
                // Restaura estilos originais
                if (originalStyle !== null) {
                    video.setAttribute('style', originalStyle);
                } else {
                    video.removeAttribute('style');
                }
                rotated = false;
                btn.textContent = '🎹 Modo Piano Roll';
            }
        };

        return btn;
    }

    function waitForVideoAndInsertButton() {
        const checkExist = setInterval(() => {
            const video = document.querySelector('video');
            const existingBtn = document.getElementById('piano-roll-btn');

            if (video && !existingBtn) {
                const btn = createButton();
                document.body.appendChild(btn);
                clearInterval(checkExist);
            }
        }, 500);
    }

    const pageObserver = new MutationObserver(() => {
        waitForVideoAndInsertButton();
    });

    pageObserver.observe(document.body, { childList: true, subtree: true });

    waitForVideoAndInsertButton();
})();
