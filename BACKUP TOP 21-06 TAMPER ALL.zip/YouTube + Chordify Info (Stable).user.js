// ==UserScript==
// @name         YouTube + Chordify Info (Stable)
// @namespace    http://tampermonkey.net/
// @version      6.0
// @description  Adiciona Key, BPM e link Chordify ao título do YouTube (não Music).
// @author       Você
// @match        https://www.youtube.com/watch*
// @grant        GM_xmlhttpRequest
// @connect      chordify.net
// ==/UserScript==

(function () {
    'use strict';

    const NOTES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
    const enharmonics = {
        'Cb': 'B', 'Db': 'C#', 'Eb': 'D#', 'Fb': 'E',
        'Gb': 'F#', 'Ab': 'G#', 'Bb': 'A#',
        'E#': 'F', 'B#': 'C'
    };
    const reverseEnharmonics = {
        'C#': 'Db', 'D#': 'Eb', 'F#': 'Gb', 'G#': 'Ab', 'A#': 'Bb'
    };

    let lastVideoId = null;

    function getRelativeKey(key) {
        const [rawNote, type] = key.split(':');
        const sharpNote = enharmonics[rawNote] || rawNote;
        const idx = NOTES.indexOf(sharpNote);
        if (idx === -1 || !type) return key;

        let relativeNote;
        if (type === 'min') {
            relativeNote = NOTES[(idx + 3) % 12];
        } else if (type === 'maj') {
            relativeNote = NOTES[(idx + 9) % 12];
        } else {
            return key;
        }

        if (rawNote.includes('b') && reverseEnharmonics[relativeNote]) {
            relativeNote = reverseEnharmonics[relativeNote];
        }

        return `${key}/${relativeNote}:${type === 'min' ? 'maj' : 'min'}`;
    }

    function formatBpmVariants(bpm) {
        const half = (bpm / 2).toFixed(1);
        const double = (bpm * 2).toFixed(0);
        return `${bpm}/${half}/${double}`;
    }

    function fetchChordifyInfo(videoId, callback) {
        GM_xmlhttpRequest({
            method: "GET",
            url: `https://chordify.net/api/v2/songs/youtube:${videoId}`,
            headers: { "Accept": "application/json" },
            onload: function (response) {
                try {
                    const data = JSON.parse(response.responseText);
                    callback(null, data);
                } catch (err) {
                    callback(err, null);
                }
            },
            onerror: function (err) {
                callback(err, null);
            }
        });
    }

    function clearPreviousInfo(titleEl) {
        if (!titleEl) return;
        const spans = titleEl.querySelectorAll('span[data-chordify]');
        spans.forEach(span => span.remove());
        titleEl.dataset.chordifyUpdated = 'false';
    }

    function updateTitleWithInfo(titleEl, infoText, chordifyLink) {
        if (!titleEl || titleEl.dataset.chordifyUpdated === 'true') return;

        const infoSpan = document.createElement('span');
        infoSpan.dataset.chordify = 'true';
        infoSpan.style.marginLeft = '10px';

        if (chordifyLink) {
            const a = document.createElement('a');
            a.href = chordifyLink;
            a.textContent = infoText;
            a.target = '_blank';
            a.style.color = '#1db954';
            a.style.textDecoration = 'none';
            a.title = 'Ver no Chordify';
            infoSpan.appendChild(document.createTextNode(' | '));
            infoSpan.appendChild(a);
        } else {
            infoSpan.textContent = ` | ${infoText}`;
        }

        titleEl.appendChild(infoSpan);
        titleEl.dataset.chordifyUpdated = 'true';
    }

    function processMusic() {
        const videoId = new URLSearchParams(window.location.search).get('v');
        const titleEl = document.querySelector('ytd-watch-metadata yt-formatted-string[title]');

        if (!videoId || !titleEl) return;
        if (videoId === lastVideoId && titleEl.dataset.chordifyUpdated === 'true') return;

        lastVideoId = videoId;
        clearPreviousInfo(titleEl);

        fetchChordifyInfo(videoId, (err, data) => {
            if (err || !data) return;

            if (data.errorCode === 'SongNotFound') {
                updateTitleWithInfo(titleEl, 'NotKeyAndBPM', null);
                return;
            }

            const bpm = data.chordInfo?.derivedBpm;
            const key = data.chordInfo?.derivedKey;
            const slug = data.slug;

            if (bpm && key && slug) {
                const fullKey = getRelativeKey(key);
                const fullBpm = formatBpmVariants(bpm);
                const infoText = `Key: ${fullKey} | BPM: ${fullBpm}`;
                const chordifyLink = `https://chordify.net/en/chords/${slug}`;
                updateTitleWithInfo(titleEl, infoText, chordifyLink);
            }
        });
    }

    function observeChanges() {
        const target = document.querySelector('ytd-watch-flexy');
        if (!target) return;

        const observer = new MutationObserver(() => {
            setTimeout(processMusic, 300);
        });

        observer.observe(target, {
            childList: true,
            subtree: true
        });
    }

    const waitForTarget = setInterval(() => {
        const target = document.querySelector('ytd-watch-flexy');
        if (target) {
            clearInterval(waitForTarget);
            observeChanges();
        }
    }, 500);
})();
