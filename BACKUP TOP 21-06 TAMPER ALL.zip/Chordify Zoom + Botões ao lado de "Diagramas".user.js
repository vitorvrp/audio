// ==UserScript==
// @name         Chordify Zoom + Botões ao lado de "Diagramas"
// @namespace    http://tampermonkey.net/
// @version      1.2
// @description  Adiciona botões de zoom ao lado do botão "Diagramas" no Chordify Embed
// @match        https://chordify.net/en/embed/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    let currentZoom = 1.0;

    function aplicarZoom() {
        document.body.style.transform = `scale(${currentZoom})`;
        document.body.style.transformOrigin = '0 0';
        document.body.style.width = `${100 / currentZoom}%`;
        document.body.style.height = `${100 / currentZoom}%`;
        console.log(`[Chordify Zoom] Zoom ajustado para ${currentZoom.toFixed(2)}`);
    }

    function criarBotoesZoom() {
        const viewToggle = document.getElementById('viewToggle');
        if (!viewToggle) {
            console.log('[Chordify Zoom] viewToggle não encontrado. Tentando novamente...');
            setTimeout(criarBotoesZoom, 500);
            return;
        }

        // Criar container para os botões
        const container = document.createElement('div');
        container.style.display = 'inline-flex';
        container.style.gap = '5px';
        container.style.marginLeft = '10px';

        // Estilo comum aos botões
        const estiloBotao = `
            padding: 5px 10px;
            font-size: 16px;
            cursor: pointer;
            background-color: #eee;
            border: 1px solid #ccc;
            border-radius: 4px;
        `;

        // Botão de zoom +
        const botaoMais = document.createElement('button');
        botaoMais.textContent = '+';
        botaoMais.setAttribute('title', 'Aumentar Zoom');
        botaoMais.style.cssText = estiloBotao;
        botaoMais.onclick = () => {
            currentZoom = Math.min(currentZoom + 0.1, 3);
            aplicarZoom();
        };

        // Botão de zoom -
        const botaoMenos = document.createElement('button');
        botaoMenos.textContent = '−';
        botaoMenos.setAttribute('title', 'Diminuir Zoom');
        botaoMenos.style.cssText = estiloBotao;
        botaoMenos.onclick = () => {
            currentZoom = Math.max(currentZoom - 0.1, 0.3);
            aplicarZoom();
        };

        container.appendChild(botaoMais);
        container.appendChild(botaoMenos);

        // Inserir ao lado do botão "diagramas"
        viewToggle.appendChild(container);
    }

    window.addEventListener('load', criarBotoesZoom);
})();
